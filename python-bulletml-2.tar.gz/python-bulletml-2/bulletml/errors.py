"""Base error classes for bulletml."""

class Error(Exception):
    """Base error class for bulletml."""
    pass

